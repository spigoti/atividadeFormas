package com.felipe.calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainResultadoActivity extends AppCompatActivity {

    private String tipo;
    private Double resultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_resultado);
        ImageView img = findViewById(R.id.imageView);
        TextView calculo = findViewById(R.id.resultado);

        Intent intentRebedora = getIntent();
        Bundle parametros = intentRebedora.getExtras();

        tipo = parametros.getString("chave_tipo");
        resultado = parametros.getDouble("chave_resultado");

        calculo.setText("Área: " + resultado.toString() + " m²");

        switch (tipo){
            case "bolinha":
                img.setImageDrawable(getResources().getDrawable(R.mipmap.ic_circle_foreground));
                break;
            case "quadrado":
                img.setImageDrawable(getResources().getDrawable(R.mipmap.ic_square_foreground));
                break;
            case "retangulo":
                img.setImageDrawable(getResources().getDrawable(R.mipmap.ic_rectangle_foreground));
                break;
            case "triangulo":
                img.setImageDrawable(getResources().getDrawable(R.mipmap.ic_triangle_foreground));
                break;


        }

    }

    public void jogarDeNovo(View view) {
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(intent);
    }
}
