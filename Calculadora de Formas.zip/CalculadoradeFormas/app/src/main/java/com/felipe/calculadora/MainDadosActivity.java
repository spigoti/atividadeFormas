package com.felipe.calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainDadosActivity extends AppCompatActivity {

    private String tipo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_dados);

        Intent intentTipo = getIntent();
        tipo = intentTipo.getStringExtra("tipo");

        if (tipo.equalsIgnoreCase("circulo")){
            TextView primeiroTexto = findViewById(R.id.primeiroTexto);
            //private TextView primeiroInput = findViewById(R.id.primeiroInput);
            TextView segundoTexto = findViewById(R.id.segundoTexto);
            TextView segundoInput = findViewById(R.id.segundoInput);
            primeiroTexto.setText("Raio");
            segundoInput.setVisibility(View.INVISIBLE);
            segundoTexto.setVisibility(View.INVISIBLE);

        }else {
            TextView primeiroTexto = findViewById(R.id.primeiroTexto);
            //private TextView primeiroInput = findViewById(R.id.primeiroInput);
            TextView segundoTexto = findViewById(R.id.segundoTexto);
            TextView segundoInput = findViewById(R.id.segundoInput);
            primeiroTexto.setText("Base");
            segundoTexto.setText("Altura");
            segundoTexto.setVisibility(View.VISIBLE);
            segundoInput.setVisibility(View.VISIBLE);


        };

        /*Button calcular = (Button) findViewById(R.id.btCalcular);
        calcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentResultado = new Intent();
                //Bundle parametros = intentResultado
            }
        });*/


    }


    public void terceiraTela(View view) {

        EditText primeiroInput = findViewById(R.id.primeiroInput);
        EditText segundoInput = findViewById(R.id.segundoInput);

        double raio, base, altura;

        Intent intent = new Intent(getApplicationContext(), MainResultadoActivity.class);


        if (tipo.equalsIgnoreCase("circulo")){
            raio = Double.parseDouble(primeiroInput.getText().toString());
            Double resultado = Math.PI * Math.pow(raio, 2);
            intent.putExtra("calculo", resultado);



        }else if (tipo.equalsIgnoreCase("quadrado")){
            base = Double.parseDouble(primeiroInput.getText().toString());
            altura = Double.parseDouble(segundoInput.getText().toString());
            Double resultado = (base * altura);
            intent.putExtra("calculo", resultado);

            if (base != altura){
                tipo = "retangulo";
            }

        }else if (tipo.equalsIgnoreCase("triangulo")){
            base = Double.parseDouble(primeiroInput.getText().toString());
            altura = Double.parseDouble(segundoInput.getText().toString());
            Double resultado = (base * altura) / 2;
            intent.putExtra("calculo", resultado);

        };


        intent.putExtra("tipo", tipo);
        startActivity(intent);


    }

    public void primeiraTela(View view) {

        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(intent);

    }
}
