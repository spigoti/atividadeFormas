package com.felipe.calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainDadosActivity extends AppCompatActivity {

    private String tipo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_dados);

        Intent intentTipo = getIntent();
        tipo = intentTipo.getStringExtra("tipo");

        if (tipo.equalsIgnoreCase("circulo")){
            TextView primeiroTexto = findViewById(R.id.primeiroTexto);
            //private TextView primeiroInput = findViewById(R.id.primeiroInput);
            TextView segundoTexto = findViewById(R.id.segundoTexto);
            TextView segundoInput = findViewById(R.id.segundoInput);
            primeiroTexto.setText("Raio");
            segundoInput.setVisibility(View.INVISIBLE);
            segundoTexto.setVisibility(View.INVISIBLE);

        }else {
            TextView primeiroTexto = findViewById(R.id.primeiroTexto);
            //private TextView primeiroInput = findViewById(R.id.primeiroInput);
            TextView segundoTexto = findViewById(R.id.segundoTexto);
            TextView segundoInput = findViewById(R.id.segundoInput);
            primeiroTexto.setText("Base");
            segundoTexto.setText("Altura");
            segundoTexto.setVisibility(View.VISIBLE);
            segundoInput.setVisibility(View.VISIBLE);


        };

        /*Button calcular = (Button) findViewById(R.id.btCalcular);
        calcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentResultado = new Intent();
                //Bundle parametros = intentResultado
            }
        });*/


    }


    public void terceiraTela(View view) {

        EditText primeiroInput = findViewById(R.id.segundoInput);
        EditText segundoInput = findViewById(R.id.segundoInput);

        double raio, base, altura, resultado;

        Bundle parametros = new Bundle();

        if (tipo.equalsIgnoreCase("circulo")){
            raio = Double.parseDouble(primeiroInput.getText().toString());
            resultado = Math.PI * Math.pow(raio, 2);

            parametros.putString("chave_tipo","circulo");
            parametros.putDouble("chave_resultado", resultado);

        }else if (tipo.equalsIgnoreCase("quadrado")){
            base = Double.parseDouble(primeiroInput.getText().toString());
            altura = Double.parseDouble(segundoInput.getText().toString());
            resultado = (base * altura);
            if (base == altura){
                parametros.putString("tipo","quadrado");
            } else{
                parametros.putString("tipo","retangulo");
            }

            parametros.putDouble("resultado", resultado);

        }else if (tipo.equalsIgnoreCase("triangulo")){
            base = Double.parseDouble(primeiroInput.getText().toString());
            altura = Double.parseDouble(segundoInput.getText().toString());
            resultado = (base * altura) / 2;

            parametros.putString("tipo","triangulo");
            parametros.putDouble("resultado", resultado);

        };


        Intent intent = new Intent(getApplicationContext(), MainResultadoActivity.class);
        intent.putExtras(parametros);
        startActivity(intent);


    }

    public void primeiraTela(View view) {

        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(intent);

    }
}
