package com.felipe.calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void segundaTelaQuadrado(View view) {

        Intent intent1 = new Intent(getApplicationContext(), MainDadosActivity.class);
        //Bundle parametros = new Bundle();
        intent1.putExtra("tipo", "quadrado");
        startActivity(intent1);

    }

    public void segundaTelaCirculo(View view) {

        Intent intent1 = new Intent(getApplicationContext(), MainDadosActivity.class);
        intent1.putExtra("tipo", "circulo");
        startActivity(intent1);

    }

    public void segundaTelaTriangulo(View view) {

        Intent intent1 = new Intent(getApplicationContext(), MainDadosActivity.class);
        intent1.putExtra("tipo", "triangulo");
        startActivity(intent1);

    }
}
